# data/ folder

Put your two project datasets here and the app will pick them up automatically (no upload needed):

| File (any name matching the pattern) | Used by |
|---|---|
| `Distribution_Data.csv`  (`Distribution*.csv`) | Module 2 - Distribution fitting |
| `Markov_Random_Forest (1).xlsx`  (`Markov*.xlsx`) | Module 3 (Markov) and Module 4 (Random Forest) |

If neither file is present (and nothing is uploaded in the sidebar) the app runs on clearly-labelled **synthetic demo data**.

> Note: if your GitHub repository is public, files committed here are public too. Check the IUCN Red List terms of use
> before redistributing data; otherwise keep the repo private or use the sidebar upload instead.
